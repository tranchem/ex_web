<div class="fluid_container">
    <div class="camera_wrap camera_coffee_skin" id="camera_wrap_1">
        <div data-thumb="https://popeyes.vn/media/mbimages/thumbs/mbimages/1/3/1349x580-min.jpg"
            data-src="https://popeyes.vn/media/mbimages/1/3/1349x580-min.jpg"
            data-link="" data-target="_self">
        </div>
        <div data-thumb="https://popeyes.vn/media/mbimages/thumbs/mbimages/h/o/home_2005_app.jpg"
            data-src="https://popeyes.vn/media/mbimages/h/o/home_2005_app.jpg"
            data-link="" data-target="_self">
        </div>

    </div>
</div>
<div class="swiper-container">
    <div class="slider-control left"></div>
    <div class="slider-control right"></div>
    <ul class="swiper">
        <li class="swiper-slide">
            <img src="../assets/media/mbimages/5/2/520x390-min.jpg" />
        </li>
        <li class="swiper-slide">
            <img src="../assets/media/mbimages/h/o/home_2005_app-mobile.jpg" />
        </li>
    </ul>
</div>
<div style="clear:both; display:block;"></div>
<div class="std">
    <div class="col-md-12  clearfix head-body">
        <div class="container">
            <div class="col-md-3 col-sm-6">
                <div class="widget widget-static-block">
                    <div class="body-items">
                        <div class="img-main"><a href="products.html" target="_blank"><img alt="image"
                                    src="../assets/media/wysiwyg/popeyes/home_block_menu_V.jpg" /></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="widget widget-static-block">
                    <div class="body-items">
                        <div class="img-main"><a href="giaohang.html"><img alt="image"
                                    src="../assets/media/wysiwyg/popeyes/home_block_deli_V.jpg" /></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="widget widget-static-block">
                    <div class="body-items">
                        <div class="img-main"><a href="https://bitly.com/APPLY-IPPGFB"><img alt="image"
                                    src="../assets/media/wysiwyg/home_block_career_V.jpg" /></a>
                        </div>
                        <div class="img-layer-1"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="widget widget-static-block">
                    <div class="body-items">
                        <div class="img-main"><a href="birthday.html"><img alt="image"
                                    src="../assets/media/wysiwyg/popeyes/home_block_birthday_V.jpg" /></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>