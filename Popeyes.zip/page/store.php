<div class="store-map col-lg-12 col-md-12 col-sm-12 col-xs-12" id="store_map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.597833850267!2d105.8264018146985!3d21.008752186009172!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac800f450807%3A0x419a49bcd94b693a!2zSOG7jWMgdmnhu4duIE5nw6JuIGjDoG5n!5e0!3m2!1svi!2s!4v1594814096099!5m2!1svi!2s" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

</div>