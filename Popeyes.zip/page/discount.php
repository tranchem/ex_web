<div class="promotion-wrap">
    <div class="container container_m">
                <div class="row">
            <div class="col-md-12">
                <div class="promotion-head">
                    <header class="title-head chunk-font">
                        <p><img alt="promotiontitle" src="https://popeyes.vn/media/wysiwyg/popeyes/promo_title_V.png"></p>
<div class="content">
<p style="text-align: center;">Mỗi ngày luôn có điều mới mẻ và thú vị chờ đợi bạn tại Popeyes® Louisiana Kitchen.
Hãy khám phá những chương trình khuyến mãi, các món ăn mới nhất và cả những phần quà đặc biệt bên dưới!</p>
</div>
<style><!--
.content p { font-size: 16px }
--></style>                    </header>
                </div>
            </div>
        </div>
        <div class="row protab">
                        
        </div>
                            <div class="item-promotion">
                <div class="row">
                    <div class="col-md-12">
                        
                            <figure class="image-item">
                                <img alt="promotion_image_0" src="https://popeyes.vn/media/images/promo_2006_m2t3-v.jpg">
                            </figure>
                        </a>
                    </div>
                </div>
                                            </div>
                                <div class="item-promotion">
                <div class="row">
                    <div class="col-md-12">
                       
                            <figure class="image-item">
                                <img alt="promotion_image_1" src="https://popeyes.vn/media/images/promo_1804_happyhour.jpg">
                            </figure>
                        </a>
                    </div>
                </div>
                            </div>
                                <div class="item-promotion">
                <div class="row">
                    <div class="col-md-12">
                        
                            <figure class="image-item">
                                <img alt="promotion_image_2" src="https://popeyes.vn/media/images/promo_2007_bigorder.jpg">
                            </figure>
                        </a>
                    </div>
                </div>
                                            </div>
                                <div class="item-promotion">
                <div class="row">
                    <div class="col-md-12">
                        
                            <figure class="image-item">
                                <img alt="promotion_image_3" src="https://popeyes.vn/media/images/promo_1000x400_m1t1.jpg">
                            </figure>
                        </a>
                    </div>
                </div>
                                            </div>
                            <div class="row promotion-pagination">
            <div class="col-md-12">
                
        <div class="pager pager-no-toolbar">
    
        <div class="count-container">
                                <p class="amount amount--no-pages">
                <strong>4 Sản phẩm</strong>
            </p>
                    
                <div class="limiter">
            <label>Hiển thị</label>
            <select onchange="setLocation(this.value)" title="Results per page">
                            <option value="https://popeyes.vn/promotions/?limit=5">
                    5                </option>
                            <option value="https://popeyes.vn/promotions/?limit=10">
                    10                </option>
                            <option value="https://popeyes.vn/promotions/?limit=20">
                    20                </option>
                            <option value="https://popeyes.vn/promotions/?limit=all" selected="selected">
                    all                </option>
                        </select>
        </div>
            </div>
    
    
        </div>
    
            </div>
        </div>
    </div>
</div>