<div class="main-container col1-layout">
                <div class="main">
                    <div class="col-main">
                        <div class="std">
                            <div class="col-md-12 body-coupon">
                                <div class="container content-story">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="story-head">
                                                <div class="title-head-story chunk-font"></div>
                                                <div class="logo-poperyes"><img 
                                                        src=".././assets/media/wysiwyg/popeyes/our-store.png" /></div>
                                                <div class="description">
                                                    <p>Hãy liên hệ trực tiếp với đội ngũ quản lý và nhân viên để được tư vấn nhiệt tình nhất.</p>
                                                    <h4>HOTLINE:</h4>
                                                    <p>1900 6008</p>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                  
                                   
                                    <div class="col-md-12">
                                        <div class="mod-head"><img 
                                                src=".././assets/media/lienhe/thanhmai.png" /></div>
                                    </div>
                                    <div class="row">
                                        <div class="year-1970">
                                            <div class="col-md-7">
                                                <div class="image-his right"><img style="width: 200px;height: 250px;"
                                                        src=".././assets/media/lienhe/mai.jpg" />
                        
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="text-his">
                                                    <h4>LÊ THỊ THANH MAI:</h4>
                                                    <LI>Số điện thoại: 0367194451</LI>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-md-12">
                                        <div class="mod-head"><img 
                                                src=".././assets/media/lienhe/tuchem.png" /></div>
                                    </div>
                                    <div class="row">
                                        <div class="year-1970">
                                            <div class="col-md-7">
                                                <div class="image-his right"><img style="width: 200px;height: 250px;"
                                                        src=".././assets/media/lienhe/tu.jpg" />
                        
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="text-his">
                                                    <h4>TRẦN VĂN TÚ:</h4>
                                                    <LI>Số điện thoại: 0987675343</LI>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-md-12">
                                        <div class="mod-head"><img 
                                                src=".././assets/media/lienhe/ducviet.png" /></div>
                                    </div>
                                    <div class="row">
                                        <div class="year-1970">
                                            <div class="col-md-7">
                                                <div class="image-his right"><img style="width: 200px;height: 250px;"
                                                        src=".././assets/media/lienhe/viet.jpg" />
                        
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="text-his">
                                                    <h4>MAI ĐỨC VIỆT:</h4>
                                                    <LI>Số điện thoại: 0986777543</LI>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="mod-head"><img 
                                                src=".././assets/media/lienhe/ngocquynh.png" /></div>
                                    </div>
                                    <div class="row">
                                        <div class="year-1970">
                                            <div class="col-md-7">
                                                <div class="image-his right"><img style="width: 200px;height: 250px;"
                                                        src=".././assets/media/lienhe/quynh.jpg" />
                        
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="text-his">
                                                    <h4>NGUYỄN NGỌC QUỲNH:</h4>
                                                    <LI>Số điện thoại: 0967453222</LI>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>